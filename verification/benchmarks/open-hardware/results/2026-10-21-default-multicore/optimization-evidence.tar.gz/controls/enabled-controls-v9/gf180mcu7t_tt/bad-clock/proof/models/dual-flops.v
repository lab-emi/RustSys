// Generated from the pinned Liberty ff/pin declarations.

