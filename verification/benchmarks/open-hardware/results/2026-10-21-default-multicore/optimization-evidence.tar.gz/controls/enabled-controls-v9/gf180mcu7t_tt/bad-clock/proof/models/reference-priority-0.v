
module enabled(input clk,en,rst_n,input [7:0] d,
               output reg [7:0] q,qr,output reg qfall,qlow);
  always @(posedge clk) if(en) q<=d;
  always @(posedge clk or negedge rst_n) if(!rst_n) qr<=0; else if(en) qr<=d;
  always @(negedge clk) if(en) qfall<=d[0];
  always @(posedge clk) if(!en) qlow<=d[1];
endmodule
