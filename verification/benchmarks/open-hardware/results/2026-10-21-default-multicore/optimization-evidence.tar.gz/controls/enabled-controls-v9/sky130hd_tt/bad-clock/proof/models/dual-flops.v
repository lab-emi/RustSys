// Generated from the pinned Liberty ff/pin declarations.
module sky130_fd_sc_hd__dfxbp_1(CLK,D,Q,Q_N);
input CLK;
input D;
output Q;
output Q_N;
reg __lec_physical_state;
always @(posedge CLK) __lec_physical_state <= D;
assign Q = __lec_physical_state;
assign Q_N = ~__lec_physical_state;
endmodule
module sky130_fd_sc_hd__dfxbp_2(CLK,D,Q,Q_N);
input CLK;
input D;
output Q;
output Q_N;
reg __lec_physical_state;
always @(posedge CLK) __lec_physical_state <= D;
assign Q = __lec_physical_state;
assign Q_N = ~__lec_physical_state;
endmodule
