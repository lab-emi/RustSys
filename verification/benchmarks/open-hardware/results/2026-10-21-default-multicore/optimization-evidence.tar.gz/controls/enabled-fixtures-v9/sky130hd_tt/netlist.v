module enabled(
  input wire clk,
  input wire en,
  input wire rst_n,
  input wire [7:0] d,
  output wire [7:0] q,
  output wire [7:0] qr,
  output wire qfall,
  output wire qlow
);
  wire \q[0] ;
  wire \q[1] ;
  wire \q[2] ;
  wire \q[3] ;
  wire \q[4] ;
  wire \q[5] ;
  wire \q[6] ;
  wire \q[7] ;
  wire \qr[0] ;
  wire \qr[1] ;
  wire \qr[2] ;
  wire \qr[3] ;
  wire \qr[4] ;
  wire \qr[5] ;
  wire \qr[6] ;
  wire \qr[7] ;
  wire n0;
  sky130_fd_sc_hd__clkinv_1 g0 (.A(clk), .Y(n0));
  sky130_fd_sc_hd__sdfxtp_1 r0 (.SCD(d[0]), .CLK(clk), .SCE(en), .D(\q[0] ), .Q(\q[0] ));
  sky130_fd_sc_hd__sdfxtp_1 r1 (.SCD(d[1]), .CLK(clk), .SCE(en), .D(\q[1] ), .Q(\q[1] ));
  sky130_fd_sc_hd__sdfxtp_1 r2 (.SCD(d[2]), .CLK(clk), .SCE(en), .D(\q[2] ), .Q(\q[2] ));
  sky130_fd_sc_hd__sdfxtp_1 r3 (.SCD(d[3]), .CLK(clk), .SCE(en), .D(\q[3] ), .Q(\q[3] ));
  sky130_fd_sc_hd__sdfxtp_1 r4 (.SCD(d[4]), .CLK(clk), .SCE(en), .D(\q[4] ), .Q(\q[4] ));
  sky130_fd_sc_hd__sdfxtp_1 r5 (.SCD(d[5]), .CLK(clk), .SCE(en), .D(\q[5] ), .Q(\q[5] ));
  sky130_fd_sc_hd__sdfxtp_1 r6 (.SCD(d[6]), .CLK(clk), .SCE(en), .D(\q[6] ), .Q(\q[6] ));
  sky130_fd_sc_hd__sdfxtp_1 r7 (.SCD(d[7]), .CLK(clk), .SCE(en), .D(\q[7] ), .Q(\q[7] ));
  sky130_fd_sc_hd__sdfrtp_1 r8 (.SCD(d[0]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[0] ), .Q(\qr[0] ));
  sky130_fd_sc_hd__sdfrtp_1 r9 (.SCD(d[1]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[1] ), .Q(\qr[1] ));
  sky130_fd_sc_hd__sdfrtp_1 r10 (.SCD(d[2]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[2] ), .Q(\qr[2] ));
  sky130_fd_sc_hd__sdfrtp_1 r11 (.SCD(d[3]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[3] ), .Q(\qr[3] ));
  sky130_fd_sc_hd__sdfrtp_1 r12 (.SCD(d[4]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[4] ), .Q(\qr[4] ));
  sky130_fd_sc_hd__sdfrtp_1 r13 (.SCD(d[5]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[5] ), .Q(\qr[5] ));
  sky130_fd_sc_hd__sdfrtp_1 r14 (.SCD(d[6]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[6] ), .Q(\qr[6] ));
  sky130_fd_sc_hd__sdfrtp_1 r15 (.SCD(d[7]), .CLK(clk), .RESET_B(rst_n), .SCE(en), .D(\qr[7] ), .Q(\qr[7] ));
  sky130_fd_sc_hd__sdfxtp_1 r16 (.SCD(d[0]), .CLK(n0), .SCE(en), .D(qfall), .Q(qfall));
  sky130_fd_sc_hd__sdfxtp_1 r17 (.D(d[1]), .CLK(clk), .SCE(en), .SCD(qlow), .Q(qlow));
  assign q[0] = \q[0] ;
  assign q[1] = \q[1] ;
  assign q[2] = \q[2] ;
  assign q[3] = \q[3] ;
  assign q[4] = \q[4] ;
  assign q[5] = \q[5] ;
  assign q[6] = \q[6] ;
  assign q[7] = \q[7] ;
  assign qr[0] = \qr[0] ;
  assign qr[1] = \qr[1] ;
  assign qr[2] = \qr[2] ;
  assign qr[3] = \qr[3] ;
  assign qr[4] = \qr[4] ;
  assign qr[5] = \qr[5] ;
  assign qr[6] = \qr[6] ;
  assign qr[7] = \qr[7] ;
endmodule
